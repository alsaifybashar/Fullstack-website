# TDDD27_2023_Avancerad_webbprogrammering

SCREENCAST:
https://drive.google.com/drive/folders/18wMTWNp92scpZynhjtjbylDIWJYhlUS6?usp=sharing
## EnMath concept

EnMath is a mathematic website for university students. The website provides math formulas and definition for students at university level. The website will test students knowledge by having a test at the end and tell the student where it should focus more in order to improve. The website will include algorithm that will show up more questions in the area where the student have to improve. The website also provide chatGPT that will be there to help student if something is not clear.

## Functional requirement

-  Being able to log in using facebook/google account to log in ✔️
-  Search the program you are studying ✔️
-  Search the course you want to study ✔️
- Content related to the course that was selected 🚧
- Adapting the question type and difficulty after user level 📝
-  Adding chatGPT to help student if something is unclear ✔️


```
📝 - TODO

🚧 - WORKING ON IT

✔️ - Done
```

## Non-Functional requirement

- User friendly and simple design of the webiste
- Self-documenting code
- Vue framwork [Frontend]
- Express.js [Backend]
- Including API:s from OpenAI, Google, Facebook


## Possible features that could be added later
- 
- 
- 



## Deadlines
- [~] 📍 Register on webreg April 9

- [~] 📍 Create Project April 9

- [~] 📍 Functional and technological specification  on repo in readme.md. April 9 

- [~] 📍 Project mid-course seminar. April 25, 26, 27 (book on webreg - TBA)*

- [~]📍 Individual oral code screencast. June 4 (screencast link on gitrepo)

- [~] 📍 Project screencast. June 4 (screencast link on gitrepo)

- [~] 📍 Final source code upload. June 4

- [~] 📍 Late submissions after summer: email examiner on the 22:th of August to book time for reexam


