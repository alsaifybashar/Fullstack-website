export const courses = {
    IT: [
      { courseName: 'TANA23 - Matematiska algoritmer och modeller', courseValue: 'TANA23' },
      { courseName: 'TATA41 - Envariabelanalys 1', courseValue: 'TATA41' },
      { courseName: 'TATA24 - Linjär algebra', courseValue: 'TATA24' },
      { courseName: 'TATA91 - En-och Flervariabelanalys', courseValue: 'TATA91' },
      { courseName: 'TAMS42 - Sannolikhetslära och statistik, grundkurs', courseValue: 'TAMS42' }
    ],
    I: [
      { courseName: 'test1 - Test 1', courseValue: 'TEST1' },
      { courseName: 'TATA91 - Flervariabelanalys', courseValue: 'TATA69' },
      { courseName: 'TATA24 - Linjär algebra', courseValue: 'TATA24' }
    ],
    D: [
      { courseName: 'test1 - Test 1', courseValue: 'TEST1' },
      { courseName: 'TATA91 - Flervariabelanalys', courseValue: 'TATA69' },
      { courseName: 'TATA24 - Linjär algebra', courseValue: 'TATA24' }
    ],
    U: [
      { courseName: 'TANA23 - Matematiska algoritmer och modeller', courseValue: 'TANA23' },
      { courseName: 'TATA41 - Envariabelanalys 1', courseValue: 'TATA41' },
      { courseName: 'TATA24 - Linjär algebra', courseValue: 'TATA24' },
      { courseName: 'TATA91 - En-och Flervariabelanalys', courseValue: 'TATA91' },
      { courseName: 'TAMS42 - Sannolikhetslära och statistik, grundkurs', courseValue: 'TAMS42' }
    ],
    Y: [
      { courseName: 'test1 - Test 1', courseValue: 'TEST1' },
      { courseName: 'TATA91 - Flervariabelanalys', courseValue: 'TATA69' },
      { courseName: 'TATA24 - Linjär algebra', courseValue: 'TATA24' }
    ],
  };
  